%Load Fuzzy Inference System from file
fismat = readfis('MarriageSystemFinal');

%fprintf('Welcome to our Fuzzy Marriage System.\n');
%fprintf('Please enter values less between 1 and 0\n');
PCval = input('Enter a value for Personal Character (0 < n < 1): ');
ELval = input('Enter a value for Education Level (0 < n < 1): ');
FSval = input('Enter a value for Financial Standing (0 < n < 1): ');
Bval = input('Enter a value for Beauty (0 < n < 1): ');
PHval = input('Enter a value for Previous History (0 < n < 1): ');

%Evaluates the fuzzy system with the given outputs
input = [PCval; ELval; FSval; Bval; PHval];

display('Marriage compatibility out of 100 is ');

%Perform fuzzy inference calculations and display it
display(evalfis(input, fismat)*100);

%Open Rule Viewer
ruleview(fismat);

%Open FIS Editor
fuzzy(fismat);

%Open Rule Editor
ruleedit(fismat);

%Open Membership Function Editor
mfedit(fismat);

surfview(fismat);

